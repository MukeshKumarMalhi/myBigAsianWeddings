<footer class="text-light bg-purple-d2 py-4 text-center text-md-left">
    <div class="container">
       <div class="row align-items-center">
           <div class="col-md-6 text-center text-md-left mb-3">
               <!-- <div class="bs-logo-footer mx-auto mx-sm-0 d-inline-block align-middle"><img src="web_asset/images/my-big-asian-wedding-logo.png" class="img-fluid" style="width:100px;" alt=""></div> -->
               <p class="d-inline-block align-middle my-2 ml-md-2">© 2020 My Big Asian Wedding Ltd</p>
           </div>
           <div class="col-md-6 text-center text-md-right mb-3">
               <p class="d-inline-block align-middle my-2 mr-md-2">Cookie Policy | Privacy Policy | Terms & Conditions </p>
               <div class="bs-socal-media text-center d-inline-block align-middle">
                   <a href="https://www.facebook.com/mybigasianwedding" target="_blank"><span class="fa-stack"><i class="fas fa-circle fa-stack-2x text-warning"></i><i class="fab fa-facebook-f fa-stack-1x fa-inverse"></i></span></a>
                   <a href="https://www.instagram.com/mybigasianweddinguk/" target="_blank"><span class="fa-stack"><i class="fas fa-circle fa-stack-2x text-warning"></i><i class="fab fa-instagram fa-stack-1x fa-inverse"></i></span></a>
                   <a href="https://www.linkedin.com/company/mybigasianwedding/" target="_blank"><span class="fa-stack"><i class="fas fa-circle fa-stack-2x text-warning"></i><i class="fab fa-linkedin fa-stack-1x fa-inverse"></i></span></a>
                   <a href="https://in.pinterest.com/mybigasianwedding/" target="_blank"><span class="fa-stack"><i class="fas fa-circle fa-stack-2x text-warning"></i><i class="fab fa-pinterest-p fa-stack-1x fa-inverse"></i></span></a>
                   <a href="https://twitter.com/BigAsianWedding" target="_blank"><span class="fa-stack"><i class="fas fa-circle fa-stack-2x text-warning"></i><i class="fab fa-twitter fa-stack-1x fa-inverse"></i></span></a>
               </div>
           </div>
       </div>
   </div>
</footer>
