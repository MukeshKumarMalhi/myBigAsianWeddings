<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mybigasianweeding\resources\views/website/dashboard.blade.php ENDPATH**/ ?>