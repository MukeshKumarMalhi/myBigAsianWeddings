<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/','WebController@index');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/signup', 'WebController@signup');

Route::get('/auth/redirect/{provider}', 'Auth\SocialController@redirect');
Route::get('/callback/{provider}', 'Auth\SocialController@callback');



Route::get('/view_countries', 'Admin\BusinessController@view_countries');
Route::post('store_country', 'Admin\BusinessController@store_country');
Route::post('update_country', 'Admin\BusinessController@update_country');
Route::post('delete_country', 'Admin\BusinessController@delete_country');

Route::get('/view_categories', 'Admin\BusinessController@view_categories');
Route::post('store_category', 'Admin\BusinessController@store_category');
Route::post('update_category', 'Admin\BusinessController@update_category');
Route::post('delete_category', 'Admin\BusinessController@delete_category');

Route::get('/view_locations', 'Admin\BusinessController@view_locations');
Route::post('store_location', 'Admin\BusinessController@store_location');
Route::post('update_location', 'Admin\BusinessController@update_location');
Route::post('delete_location', 'Admin\BusinessController@delete_location');

Route::get('/view_features', 'Admin\BusinessController@view_features');
Route::post('store_feature', 'Admin\BusinessController@store_feature');
Route::post('update_feature', 'Admin\BusinessController@update_feature');
Route::post('delete_feature', 'Admin\BusinessController@delete_feature');

Route::get('/view_business', 'Admin\BusinessController@create_new_business');
Route::post('/store_business', 'Admin\BusinessController@store_business');
Route::get('/show_business/{id}', 'Admin\BusinessController@show_business');
Route::post('/delete_business', 'Admin\BusinessController@delete_business');
