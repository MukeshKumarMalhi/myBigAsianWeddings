<!-- Sidebar-left -->
<div id="sidebar-wrapper" class="link-light p-3">
    <!-- Menu Button -->
    <ul class="list-unstyled fa-ul co-menu ml-4 co-menu">
        <!-- <li class="active"><a href="{{ url('admin/dashboard') }}"><i class="fa-li fas fa-circle text-light"></i>Dashboard</a></li> -->
        <li class="nav-item"><a href="{{ url('view_countries') }}"><i class="fa-li fas fa-circle text-light"></i>Countries</a></li>
        <li class="nav-item"><a href="{{ url('view_locations') }}"><i class="fa-li fas fa-circle text-light"></i>Locations</a></li>
        <li class="nav-item"><a href="{{ url('view_categories') }}"><i class="fa-li fas fa-circle text-light"></i>Categories</a></li>
        <li class="nav-item"><a href="{{ url('view_features') }}"><i class="fa-li fas fa-circle text-light"></i>Features</a></li>
        <li class="nav-item"><a href="{{ url('view_business') }}"><i class="fa-li fas fa-circle text-light"></i>Businesses</a></li>
    </ul>
</div>
