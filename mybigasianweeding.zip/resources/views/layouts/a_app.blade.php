@include('website.library')
@include('admins.header')

<!-- Navbar links -->

@include('admins.sidebar')
@yield('content')


@include('admins.footer')


</body>
</html>
