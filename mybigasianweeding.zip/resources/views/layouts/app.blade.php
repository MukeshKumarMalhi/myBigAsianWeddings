@include('website.library')
@include('website.header')

<!-- Navbar links -->


@yield('content')


@include('website.footer')




</body>
</html>
