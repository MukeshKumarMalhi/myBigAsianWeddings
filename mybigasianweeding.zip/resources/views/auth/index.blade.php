@extends('layouts.app')
@section('title','Weeding planner')

@section('content')

<div class="yellow-bg yellowpen-bg">
    <div class="container">
    </div>
</div>


@endsection
