@include('website.library')
<body>
@include('website.header')
<!-- Page contents -->
  <div class="bg-grey hw-height">
    @yield('content')
  </div>
@include('website.footer')

</body>
</html>
