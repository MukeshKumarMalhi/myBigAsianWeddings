<nav class="navbar navbar-expand-lg navbar-dark bg-light nav-hw-top" id="mydiv">
    <div class="container small">
        <!-- Brand -->
        <a class="navbar-brand d-md-block mr-0" href="/" style="color: #000;">myBigAsianWeeding</a>

        @if(!Auth::check())
           <ul class="nav mx-auto mr-sm-0">
            <li class="pl-lg-1 pr-lg-1"><a href="/business_login" class="btn btn-default">Business login</a></li>
            <li class="pl-lg-1 pr-lg-1"><a href="/login" class="btn btn-default">Login</a></li>
            <li class="pl-lg-1 pr-lg-1"><a href="{{ url('/signup') }}" class="btn btn-default">Signup</a></li>
        </ul>
        @endif

        @if(Auth::check())
           <ul class="nav mx-auto mr-sm-0">
            <li class="pl-lg-1 pr-lg-1">
              <a class="dropdown-item small" href="{{ url('/logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fal fa-sign-out-alt"></i> Logout</a>
                <form id="logout-form" style="display: none;" action="{{ url('/logout') }}" method="POST">
                  @csrf
                </form>
            </li>
        </ul>
        @endif

    </div>
</nav>
