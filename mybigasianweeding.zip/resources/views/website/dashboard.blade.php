@extends('layouts.app')

@section('content')

    <!-- Page Content -->
    <h1>Dashboard</h1>
@endsection
