<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Socialite;
use Validator;
use Hash;
use App\User;
use App\Role;
use DateTime;
use Redirect;
use Response;
use File;

class SocialController extends Controller
{
  public function redirect($provider)
  {
    return Socialite::driver($provider)->redirect();
  }

  public function callback($provider)
  {

    $getInfo = Socialite::driver($provider)->user();

    $user = $this->createUser($getInfo,$provider);

    auth()->login($user);

    return Redirect::to('/home');

  }
  function createUser($getInfo,$provider){

  $user = User::where('provider_id', $getInfo->id)->first();

  if (!$user) {
    $id = uniqid();
     $user = User::create([
        'id'       => $id,
        'name'     => $getInfo->name,
        'email'    => $getInfo->email,
        'password'    => '',
        'provider' => $provider,
        'provider_id' => $getInfo->id
    ]);
  }
  return $user;
  }
}
